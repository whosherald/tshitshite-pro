<?php
/**
 * Created by PhpStorm.
 * User: marvincollins
 * Date: 1/19/19
 * Time: 8:24 AM
 */

return [
    'titleColor' => '',
    'messageColor' => '',
    'titleSize' => '38',
    'messageSize' => '38',
    'titleLineHeight' => '38',
    'messageLineHeight' => '38',
    'transitionIn' => 'flipInX',
    // 'transitionOut' => 'flipOutX',
    'zindex' => null,
    'closeOnClick' => true,
    'drag' => true,
    'progressBar' => true,
];
