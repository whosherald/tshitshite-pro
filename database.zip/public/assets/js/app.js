import '../../../resources/js/bootstrap';
$(document).ready(function () {
    $('#example').DataTable();
});
