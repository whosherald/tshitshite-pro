

<?php $__env->startComponent('mail::message'); ?>
# Hi <?php echo e($data['name']); ?>


It seems like you blocked your account after trying to login numerous times.
No worries, it happens to all the normal people, Good news is, if you recieved this email with intensions of unblocking your account, you are most probably the rightful recipient.
You can reset your password by clicking on the button below.

<?php $__env->startComponent('mail::button', ['url' => url('/reset-password', [$data['token']]) ]); ?>
Reset Password
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
   <?php /**PATH C:\xampp\htdocs\tshitshite-pro\resources\views/emails/unlockUserMail.blade.php ENDPATH**/ ?>